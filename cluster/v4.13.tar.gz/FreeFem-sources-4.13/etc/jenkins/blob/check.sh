#!/usr/bin/env bash

make check
