#!/usr/bin/env bash

make -j4
