#!/usr/bin/env bash

rm -rf /builds/workspace/freefem
