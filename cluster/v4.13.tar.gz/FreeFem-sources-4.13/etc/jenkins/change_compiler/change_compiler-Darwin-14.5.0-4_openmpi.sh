export CC=gcc
export CXX=g++
export FC=gfortran
export F77=gfortran
export MPIRUN=/usr/local/bin/mpirun 
export MPICXX=/usr/local/bin/mpicxx 
export MPIFC=/usr/local/bin/mpif90 
export MPICC=/usr/local/bin/mpicc 
