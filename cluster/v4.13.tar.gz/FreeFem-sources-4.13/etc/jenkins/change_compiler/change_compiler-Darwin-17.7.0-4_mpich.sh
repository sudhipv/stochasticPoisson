export CC=gcc-9
export CXX=g++-9
export FC=gfortran-9
export F77=gfortran-9
export MPIRUN=/Users/ci/mpich4/bin/mpirun 
export MPICXX=/Users/ci/mpich4/bin/mpicxx 
export MPIFC=/Users/ci/mpich4/bin/mpif90 
export MPICC=/Users/ci/mpich4/bin/mpicc 
