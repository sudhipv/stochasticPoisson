export CC=gcc-9
export CXX=g++-9
export FC=gfortran-9
export F77=gfortran-9
