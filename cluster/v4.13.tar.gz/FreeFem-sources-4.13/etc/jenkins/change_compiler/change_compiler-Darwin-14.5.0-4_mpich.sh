export CC=gcc
export CXX=g++
export FC=gfortran
export F77=gfortran
export MPIRUN=/usr/local/mpich3/bin/mpirun 
export MPICXX=/usr/local/mpich3/bin/mpicxx 
export MPIFC=/usr/local/mpich3/bin/mpif90 
export MPICC=/usr/local/mpich3/bin/mpicc 
