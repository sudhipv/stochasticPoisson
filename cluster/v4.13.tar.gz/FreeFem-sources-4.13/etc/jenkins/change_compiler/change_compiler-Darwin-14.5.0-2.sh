export CC=clang
export CXX=clang++
export FC=gfortran
export F77=gfortran
