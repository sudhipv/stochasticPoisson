.. _ind_contact:

*********
Community
*********

.. toctree::
   :maxdepth: 2

   roadmap
   governance
   bugs
   mailing
   meetings/meeting
   petsc_team

If you are interested in contributing to PETSc, see :doc:`/developers/contributing/index`.
