==================================
Discretization and Function Spaces
==================================

.. toctree::
   :maxdepth: 1

   DT/index
   SPACE/index
   DUALSPACE/index
   FE/index
   FV/index
   PF/index
   LANDAU/index
