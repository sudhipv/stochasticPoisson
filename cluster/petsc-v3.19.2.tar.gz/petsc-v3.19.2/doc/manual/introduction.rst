Introduction to PETSc
=====================

.. toctree::
   :maxdepth: 2

   about_this_manual
   getting_started
