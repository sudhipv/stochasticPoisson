=====
Misc.
=====

For all things nonconforming, not regularly useful, and (of items or people gathered or
considered together) of various types or from different sources that we consider
interesting enough to share.

.. toctree::
   :maxdepth: 2

   acknowledgements
   applications_publications
   prizes
   funding
   saws
   codemanagement
