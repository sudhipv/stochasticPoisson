
============
petsc4py API
============

  This is a dummy page that gets processed by Sphinx but then overwritten by the API files generated in src/binding/petsc4py

