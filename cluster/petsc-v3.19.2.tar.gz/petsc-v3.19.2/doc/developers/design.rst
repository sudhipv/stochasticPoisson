.. _design:

===================
The Design of PETSc
===================

.. toctree::
   :maxdepth: 2

   kernel
   objects
   callbacks
   matrices
   articles
